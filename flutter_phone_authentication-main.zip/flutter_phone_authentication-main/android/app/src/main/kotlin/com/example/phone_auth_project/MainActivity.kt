package com.example.phone_auth_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
